# Obstacle_Avoiding_Robot
Obstacle_Avoiding_Robot
![Obstacle Avoiding Robot using Arduino and L293d](https://user-images.githubusercontent.com/57707946/73702842-cf867b00-470f-11ea-8dd8-f32f9d5bfc0a.jpg)
![obstacle avoiding robot using arduino uno and L293d with hc-sr04 sensor](https://user-images.githubusercontent.com/57707946/73702855-ddd49700-470f-11ea-833a-8912602be1a4.jpg)
